// Richard Xia
// COMP 2406 A4
// 4/7/2017

//Include required modules (fs,mongodb,express, etc.)
var bodyParser = require("body-parser");
var express = require('express');
var fs = require('fs');
var mongoDB = require('mongodb');
var reqUrl = require("url");

var url = 'mongodb://localhost:27017/recipeDB'; //Set url to recipe DB
const ROOT = "./public_html";
var MongoClient = mongoDB.MongoClient;
var app = express();

//Set app view engine
app.set('views', './views');
app.set('view engine', 'pug');

//Handle and log app requests
app.use(function (req, res, next) {
    console.log(req.method + " request for " + req.url);
    next();
});

//Let app handle static routes and link bodyparser
app.use(express.static(ROOT)); 
app.use(bodyParser.json());    
app.use(bodyParser.urlencoded({
    extended: true
}));

//Serve index page
app.get(["/"], function (req, res) {
    res.render('index', {});  
});

//Handles requests for /recipes
app.get("/recipes", function (req, res) {
    MongoClient.connect(url, function (err, db) {
        var listRecipes = [];
        var recipeDb = db.collection("recipes");
        var curRecipe = null;
        if (err) {
            console.log('Unable to connect to the mongoDB server. Error:', err);
        }
        else {
            console.log('Connection established to', url);
            curRecipe = recipeDb.find({});
			//use curRecipe to iterate through listRecipes
            curRecipe.each(function (err, recipe) {
                if (recipe != null) {
                    listRecipes.push(recipe.name);
                }
                else {
                    res.send({names: listRecipes});
                }
            });
            db.close();
        }
    });
});

//Handles requests for /recipes/*
app.get("/recipe/*", function (req, res) {
    MongoClient.connect(url, function (err, db) {
        var recipeDb = db.collection("recipes");
        var curRecipe = null;
        var pathName = reqUrl.parse(req.url).pathname;
		//get the substring that contains recipe name
        var recipeName = pathName.substr(8, pathName.length - 1).replace(/%20/g, " ");
        if (err) {
            console.log('Unable to connect to the mongoDB server. Error:', err);
        }
        else {
            console.log('Connection established to', url);
			//Search db.collection for recipe
            curRecipe = recipeDb.find({name: recipeName});
            curRecipe.each(function (err, recipe) {
                if (recipe != null) {
                    console.log("recipe: ", recipe.name);
                    res.send(recipe);
                }
            });
            db.close();
        }
    });
});

//Handles requests for /recipe
app.post("/recipe", function (req, res) {
    MongoClient.connect(url, function (err, db) {
		var recipeDb = db.collection("recipes");
        var newRecipe;
        var recipe = req.body;
        var id = recipe._id;
		delete recipe._id;
        if (recipe.name === "") {
            res.sendStatus(400);
        }
		
        if (err) {
            console.log('Unable to connect to the mongoDB server. Error:', err);
        }
        else {
            console.log('Connection established to', url);
            curRecipe = recipeDb.find({name: recipe.name});
			
			curRecipe.on("end", function () {
                db.close();
            })
			
			//Using db.collection iterate through collection of recipes
            curRecipe.nextObject(function (err, nextRecipe) {
                if (nextRecipe != null) {
                    if (recipe._id == foundRecipe._id) {
                        newRecipe = recipe;
                    } else {
                        newRecipe = {
                            $set: {
                                duration: recipe.duration,
                                ingredients: recipe.ingredients,
                                directions: recipe.directions,
                                notes: recipe.notes
                            }
                        }
                    }
                } else {
                    newRecipe = recipe;
                }
				//Update db if recipe is unique
				recipeDb.update({},{__id:recipe.name},newRecipe,function(err,result) {
					if (err){
						console.log("err" + err);
						res.sendStatus(500);
						//return 500 if error
					}
					else {
						console.log("Add recipe "+ recipe.name);
						res.sendStatus(200);
						//return 200 if succesful
					}
				});
            });
        }
    });
});

//Handles error request for all other paths
app.all("*", function (req, res) {
    res.sendStatus(404);
});

//Start server, listen on 2406
app.listen(2406, function () {
    console.log("Server is listening on port 2406");
});