Richard Xia
101007519
4/7/2019

Required modules:
body-parser, express, mongodb, pug

To execute application:
node server.js
